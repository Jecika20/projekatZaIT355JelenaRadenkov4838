export class Rezervacija {
    vremeOd: Date;
    vremeDo:Date;
    ukupnaCena:number;
    vozilo_id:number;
}
