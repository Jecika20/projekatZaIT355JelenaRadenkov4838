import { Rezervacija } from './rezervacija';

describe('Rezervacija', () => {
  it('should create an instance', () => {
    expect(new Rezervacija()).toBeTruthy();
  });
});
