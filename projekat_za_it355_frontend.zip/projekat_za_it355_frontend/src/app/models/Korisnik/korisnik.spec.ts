import { Korisnik } from './korisnik';

describe('Korisnik', () => {
  it('should create an instance', () => {
    expect(new Korisnik()).toBeTruthy();
  });
});
