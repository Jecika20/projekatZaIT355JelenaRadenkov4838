import { SlikeVozila } from './slike-vozila';

describe('SlikeVozila', () => {
  it('should create an instance', () => {
    expect(new SlikeVozila()).toBeTruthy();
  });
});
