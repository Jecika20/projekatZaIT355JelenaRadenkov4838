export class SlikeVozila {
    id:number;
    slika:string;
}
