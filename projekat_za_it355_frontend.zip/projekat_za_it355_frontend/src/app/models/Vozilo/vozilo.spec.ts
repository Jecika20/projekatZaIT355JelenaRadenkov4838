import { Vozilo } from './vozilo';

describe('Vozilo', () => {
  it('should create an instance', () => {
    expect(new Vozilo()).toBeTruthy();
  });
});
