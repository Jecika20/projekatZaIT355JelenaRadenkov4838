import { RezervacijeKorisnika } from './rezervacije-korisnika';

describe('RezervacijeKorisnika', () => {
  it('should create an instance', () => {
    expect(new RezervacijeKorisnika()).toBeTruthy();
  });
});
