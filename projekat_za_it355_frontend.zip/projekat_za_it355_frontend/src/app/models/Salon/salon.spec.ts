import { Salon } from './salon';

describe('Salon', () => {
  it('should create an instance', () => {
    expect(new Salon()).toBeTruthy();
  });
});
