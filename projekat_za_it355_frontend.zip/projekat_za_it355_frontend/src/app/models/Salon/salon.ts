export class Salon {
    id:number;
    naziv:string;
    telefon:string;
    email:string;
    opis:string;
    adresa:string;
    grad:string;
    slika:string;
}
