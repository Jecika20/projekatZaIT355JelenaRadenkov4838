import { Component } from '@angular/core';

@Component({
  selector: 'app-onama',
  templateUrl: './onama.component.html',
  styleUrl: './onama.component.css'
})
export class OnamaComponent {

}
